package com.castres.breand.block6.p1.androidproject

interface PartnershipsClickListener {
    fun onClick(partnershipsItems: PartnershipsItems)
}