package com.castres.breand.block6.p1.androidproject

interface NewArrClickListener {

    fun onClick (newArrItems : NewArrItems)
}