package com.castres.breand.block6.p1.androidproject.dataclass

data class ComponentsItem(
    val CPU: List<CPU>,
    val GPU: List<GPU>,
    val Monitor: List<Any>
)