package com.castres.breand.block6.p1.androidproject

val COMPONENTS_ID_EXTRA = "componentsExtra"

data class ComponentsItems(
    var id: Int?,
    var prod_name: String,
    var image: String,
    var price: Int,
    var category: String,
    var description: String,
    var componentsAddToCart: Int,

)

