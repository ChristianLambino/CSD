package com.castres.breand.block6.p1.androidproject

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class DeatailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deatail)
    }
}