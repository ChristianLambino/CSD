package com.castres.breand.block6.p1.androidproject.dataclass

data class GPU(
    val category: String,
    val created_at: String,
    val description: String,
    val id: Int,
    val image: String,
    val price: String,
    val prod_name: String,
    val updated_at: String
)