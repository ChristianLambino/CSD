package com.castres.breand.block6.p1.androidproject.dataclass

data class UserList(
    val name: String,
    val email: String,
    val password: String,
    val phone: String,
    val address: String)
