package com.castres.breand.block6.p1.androidproject

interface ComponentsClickListener{
    fun onClick (componentsItems: ComponentsItems)
}