package com.castres.breand.block6.p1.androidproject.dataclass

import com.castres.breand.block6.p1.androidproject.ComponentsItems

data class ItemRequest(
    var id: Int?,
    var prod_name: String,
    var image: String, // Change the type to String
    var price: Int,
    var category: String,
    var description: String,
    var componentsAddToCart: Int
)

data class ItemResponse(
    val components: ComponentsItems,
    val token: String // Change the type to String or whatever type your token is
)

data class responseData(
    val CPU: List<CPU>,
    val GPU: List<GPU>,
    val Monitor: List<Any>
)
